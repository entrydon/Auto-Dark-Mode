const style = document.createElement("style");
style.textContent = `
  html, body {
    background-color: #121212 !important;
    color: #e0e0e0 !important;
  }

  * {
    background-color: transparent !important;
    color: #e0e0e0 !important;
    border-color: #555 !important;
  }

  a { color: #80b3ff !important; }

  img, video {
    filter: brightness(0.8) contrast(1.2);
  }

  ::selection {
    background: #555 !important;
    color: white !important;
  }
`;
document.documentElement.appendChild(style);
